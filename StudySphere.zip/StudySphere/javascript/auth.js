function signup() {
    const fullname = document.getElementById('fullname').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const semester = document.getElementById('semester').value;

    if (!fullname || !email || !password || !semester) {
        alert("Please fill all the fields!");
        return;
    }

    // Get existing users from localStorage
    let users = JSON.parse(localStorage.getItem('students')) || [];

    // Check if email already exists
    if (users.some(user => user.email === email)) {
        alert("Email already registered!");
        return;
    }

    // Add new user
    users.push({ fullname, email, password, semester });
    localStorage.setItem('students', JSON.stringify(users));

    alert("Account created successfully!");
    window.location.href = "dashboard.html"; // redirect to dashboard
}
function login() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    if(!email || !password){
        alert("Please enter both email and password!");
        return;
    }

    // Get all students from localStorage
    const users = JSON.parse(localStorage.getItem('students')) || [];

    // Find matching user
    const student = users.find(user => user.email === email && user.password === password);

    if(student){
        // Save the logged-in student for dashboard
        localStorage.setItem('loggedInStudent', JSON.stringify(student));
        window.location.href = "dashboard.html";
    } else {
        alert("Invalid email or password!");
    }
}
